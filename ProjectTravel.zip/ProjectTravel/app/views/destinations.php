<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="../css/normalize.css" type="text/css" rel="stylesheet"/>
      <link href="../css/styleTravel.css" type="text/css" rel="stylesheet"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Caveat" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet">
      <title>Travel Mood Is ON</title>
    </head>

    <body>
        <div id="project">
            <div id="header">
                <h1>Travel Mood Is <span style="font-family:'Caveat', cursive;">ON</span> &#9992;</h1>
            </div>
            
             <div class="row">
                <div class="navbar">
                    <a href="TravelMood.php">HOME</a>
                    <a href="destinations.php">DESTINATIONS</a>
                    <a href="blog.php">BLOG</a>
                    <a href="AskMe.php">ASK ME</a>
                </div>
            </div>
            
            <div id="container">
                  <div class="australia"><img src="../css/Galerija/slide33.jpg" width=200px alt="australia" title="Australia"></div>
                  <div class="india"><img src="../css/Galerija/tajmahal.jpg" width=200px alt="india" title="India"></div>
                  <div class="myanmar"><img src="../css/Galerija/bagan.jpg" width=200px alt="myanmar" title="Bagan"></div>
                  <div class="cambodia"><img src="../css/Galerija/cambodiaboat.jpg" width=200px alt="cambodia" title="Cambodia"></div>

                  <div class="country1"><h2>Australia</h2></div>  
                  <div class="country2"><h2>India</h2></div>  
                  <div class="country2"><h2>Myanmar</h2></div>  
                  <div class="country2"><h2>Cambodia</h2></div>  

                  <div class="flag1"><img src="../css/Galerija/australianFlag.jpg" width=200px alt="australianFlag" title="Australian flag"></div>
                  <div class="flag2"><img src="../css/Galerija/IndianFlag.jpg" width=200px alt="indianFlag" title="Indian flag"></div>
                  <div class="flag2"><img src="../css/Galerija/myanmarflag.png" width=200px alt="myanmarFlag" title="Myanmar flag"></div>
                  <div class="flag2"><img src="../css/Galerija/Cambodianflag.svg" width=200px alt="cambodianFlag" title="Cambodian flag"></div>

                  <div class="capital1">Capital <b>Canberra</b></div>  
                  <div class="capital2">Capital <b>New Dehli</b></div>  
                  <div class="capital2">Capital <b>Naypyidaw</b></div>  
                  <div class="capital2">Capital <b>Phnom Penh</b></div>  

                  <div class="population1">Population <b>25,368,200</b></div>  
                  <div class="population2">Population <b>1,324,171,354</b></div>  
                  <div class="population2">Population <b>53,582,855</b></div>  
                  <div class="population2">Population <b>16,245,729</b></div>  

                  <a href="ReadMore.php" class="readLink">Read more about Australia</a>
                  <a href="ReadMore.php" class="readLink">Read more about India</a>
                  <a href="ReadMore.php" class="readLink">Read more about Myanmar</a>
                  <a href="ReadMore.php" class="readLink">Read more about Cambodia</a>
            </div>  
            
            <div class="footer">
                <form class="subscribe" method="post">
                  <input type="text" placeholder="Name" name="name" required>
                  <input type="text" placeholder="Email" name="email" required>
                  <input type="submit" value="Subscribe" name="subscribe">
                </form>
            
                <div class="socialMedia">
                    <span>Follow us on social media</span>
                    <a href="https://www.instagram.com/?hl=en"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter-square"></i></a>
                </div>
                
                <div class="copyright">&copy; <?php echo date('Y')?>. All Rights Reserved.</div>
                <div class="goUp">
                    <a href="#header">Go UP!</a>
                </div>
            </div>
            
        </div>
    </body>
</html>