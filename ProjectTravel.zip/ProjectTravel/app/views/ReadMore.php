<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="../css/normalize.css" type="text/css" rel="stylesheet"/>
      <link href="../css/styleTravel.css" type="text/css" rel="stylesheet"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Caveat" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet">
      <title>Travel Mood Is ON</title>
    </head>

    <body>
        <div id="project">
            <div id="header">
                <h1>Travel Mood Is <span style="font-family:'Caveat', cursive;">ON</span> &#9992;</h1>
            </div>
            
             <div class="row">
                <div class="navbar">
                    <a href="TravelMood.php">HOME</a>
                    <a href="destinations.php">DESTINATIONS</a>
                    <a href="blog.php">BLOG</a>
                    <a href="AskMe.php">ASK ME</a>
                </div>
            </div>
            
            <div style="font-family:'Quattrocento Sans', sans-serif;">
                <h1>Sorry, information is being updated...</h1>
            </div>
            
        </div>
    </body>
</html>