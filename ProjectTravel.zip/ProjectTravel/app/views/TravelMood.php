<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="../css/normalize.css" type="text/css" rel="stylesheet"/>
      <link href="../css/styleTravel.css" type="text/css" rel="stylesheet"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Caveat" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet">
      <title>Travel Mood Is ON</title>
    </head>

    <body>
        <div id="project">
            <div id="header">
                <h1>Travel Mood Is <span style="font-family:'Caveat', cursive;">ON</span> &#9992;</h1>
            </div>
            
            <div class="row">
                <div class="navbar">
                    <a href="TravelMood.php">HOME</a>
                    <a href="destinations.php">DESTINATIONS</a>
                    <a href="blog.php">BLOG</a>
                    <a href="AskMe.php">ASK ME</a>
                </div>
            </div>
            
            <div class="row">
              <div class="slideShow">
                <slider>
                    <slide><div img src = "../css/Galerija/slide1.jpg"></div></slide>
                    <slide><div img src = "../css/Galerija/slide2.jpg"></div></slide>
                    <slide><div img src = "../css/Galerija/slide3.jpg"></div></slide>
                    <slide><div img src = "../css/Galerija/slide4.jpg"></div></slide>
                </slider>
            </div>
            </div>
            
            <div class="row">
            <div class="aboutFoto"><img src ="../css/Galerija/AUveidai.jpg" alt="aboriginalPaintings" title="Aboriginal Paintings, WA" width="400"/></div>
            
                <div class="main">
                    <h2>About me</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <h2>Why I Travel?</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
                
                <div class="row">
                    <div class="idea">
                    <h2>The Idea</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. You will find information about:</p>
                    <ul>
                      <li>Places must visit</li>
                      <li>Things to do</li>
                      <li>Transport</li>
                      <li>Accommodation</li>
                      <li>Local life</li>
                      <li>Budget tips</li>
                    </ul>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    </div>
                </div>
            </div>
            
            <div class="footer">
                <form class="subscribe" method="post">
                  <input type="text" placeholder="Name" name="name" required>
                  <input type="text" placeholder="Email" name="email" required>
                  <input type="submit" value="Subscribe" name="subscribe">
                </form>
            
                <div class="socialMedia">
                    <span>Follow us on social media</span>
                    <a href="https://www.instagram.com/?hl=en"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter-square"></i></a>
                </div>
                
                <div class="copyright">&copy; <?php echo date('Y')?>. All Rights Reserved.</div>
                <div class="goUp">
                    <a href="#header">Go UP!</a>
                </div>
            </div>
            
        </div>
    </body>
</html>