<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="../css/normalize.css" type="text/css" rel="stylesheet"/>
      <link href="../css/styleTravel.css" type="text/css" rel="stylesheet"/>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Caveat" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet">
      <title>Travel Mood Is ON</title>
    </head>

    <body>
        <div id="project">
            <div id="header">
                <h1>Travel Mood Is <span style="font-family:'Caveat', cursive;">ON</span> &#9992;</h1>
            </div>
            
            <div class="row">
                <div class="navbar">
                    <a href="TravelMood.php">HOME</a>
                    <a href="destinations.php">DESTINATIONS</a>
                    <a href="blog.php">BLOG</a>
                    <a href="AskMe.php">ASK ME</a>
                </div>
            </div>
            
            <div class="row">
                <div class="blogHeading">
                    <h1>Latests Blog Posts</h1>
                </div>
            </div>
            
            <div class="row">
                    <div class="blog1photo"><img src ="../css/Galerija/AUborder.jpg" alt="waBorder" title="Western Australia" width="400"/>
                    <h2>Australia</h2>
                    <h2>Crossing the borders in kangaroos land</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. <span id="dots">...</span><span id="more">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>
                    <button onclick="myFunction()" id="myBtn">Read more</button>
                    </div> 
                
                    <div class="blog2photo"><img src ="../css/Galerija/phphst.jpg" alt="philippines" title="Philippines road" width="400"/>
                    <h2>Philippines</h2>
                    <h2>Shipwreck diving in Coron before a storm comes</h2>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    </div>
            </div>
                
            <div class="row">
                    <div class="blog3photo"><img src ="../css/Galerija/indiaLake.jpg" alt="indianLake" title="Indian lake" width="400"/>
                    <h2>India</h2>
                    <h2>16 hour night train to Mumbai and a taste of Panipuri</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    </div>

                    <div class="blog4photo"><img src ="../css/Galerija/palmsMaldives.jpg" alt="Maldives" title="Maldives" width="400"/>
                    <h2>Maldives</h2>
                    <h2>Palm trees and a clear blue sky - Hello Paradise!</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    </div>
            </div>
            
            <div class="footer">
                <form class="subscribe" method="post">
                  <input type="text" placeholder="Name" name="name" required>
                  <input type="text" placeholder="Email" name="email" required>
                  <input type="submit" value="Subscribe" name="subscribe">
                </form>
            
                <div class="socialMedia">
                    <span>Follow us on social media</span>
                    <a href="https://www.instagram.com/?hl=en"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a>
                    <a href="https://www.twitter.com/"><i class="fa fa-twitter-square"></i></a>
                </div>
                
                <div class="copyright">&copy; <?php echo date('Y')?>. All Rights Reserved.</div>
                <div class="goUp">
                    <a href="#header">Go UP!</a>
                </div>
            </div>
            
        </div>
        
        <script>
            function myFunction() {
              var dots = document.getElementById("dots");
              var moreText = document.getElementById("more");
              var btnText = document.getElementById("myBtn");

              if (dots.style.display === "none") {
                dots.style.display = "inline";
                btnText.innerHTML = "Read more"; 
                moreText.style.display = "none";
              } else {
                dots.style.display = "none";
                btnText.innerHTML = "Read less"; 
                moreText.style.display = "inline";
              }
            }
        </script>
        
    </body>
</html>